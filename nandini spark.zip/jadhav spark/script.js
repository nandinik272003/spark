// Sample data structure
let salaryData = [];
let filteredData = [];

// DOM Elements
const csvFileInput = document.getElementById('csvFile');
const uploadBtn = document.getElementById('uploadBtn');
const fileInfo = document.getElementById('fileInfo');
const jobFilter = document.getElementById('jobFilter');
const experienceFilter = document.getElementById('experienceFilter');
const applyFiltersBtn = document.getElementById('applyFilters');
const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];

// Chart instances
let salaryChart, jobChart, experienceChart;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Load sample data initially
    loadSampleData();
    
    // Event listeners
    uploadBtn.addEventListener('click', handleFileUpload);
    applyFiltersBtn.addEventListener('click', applyFilters);
});

// Load sample data for demonstration
function loadSampleData() {
    salaryData = [
        { name: "John Smith", jobTitle: "Software Engineer", experience: "Mid-Level", salary: 85000, department: "Engineering" },
        { name: "Emily Johnson", jobTitle: "Data Analyst", experience: "Entry-Level", salary: 65000, department: "Analytics" },
        { name: "Michael Brown", jobTitle: "Product Manager", experience: "Senior", salary: 120000, department: "Product" },
        { name: "Sarah Davis", jobTitle: "UX Designer", experience: "Mid-Level", salary: 90000, department: "Design" },
        { name: "Robert Wilson", jobTitle: "Software Engineer", experience: "Senior", salary: 130000, department: "Engineering" },
        { name: "Jennifer Lee", jobTitle: "HR Specialist", experience: "Mid-Level", salary: 75000, department: "Human Resources" },
        { name: "David Miller", jobTitle: "Data Scientist", experience: "Senior", salary: 140000, department: "Analytics" },
        { name: "Lisa Taylor", jobTitle: "Marketing Manager", experience: "Senior", salary: 110000, department: "Marketing" },
        { name: "James Anderson", jobTitle: "DevOps Engineer", experience: "Mid-Level", salary: 105000, department: "Engineering" },
        { name: "Patricia Thomas", jobTitle: "Accountant", experience: "Entry-Level", salary: 55000, department: "Finance" },
        { name: "Daniel Martinez", jobTitle: "Software Engineer", experience: "Entry-Level", salary: 70000, department: "Engineering" },
        { name: "Jessica Garcia", jobTitle: "UX Designer", experience: "Senior", salary: 115000, department: "Design" },
        { name: "Thomas Robinson", jobTitle: "Data Analyst", experience: "Mid-Level", salary: 80000, department: "Analytics" },
        { name: "Margaret Clark", jobTitle: "Product Manager", experience: "Senior", salary: 125000, department: "Product" },
        { name: "Christopher Lewis", jobTitle: "Software Engineer", experience: "Mid-Level", salary: 95000, department: "Engineering" },
        { name: "Michelle Walker", jobTitle: "HR Specialist", experience: "Senior", salary: 90000, department: "Human Resources" },
        { name: "Anthony Hall", jobTitle: "Data Scientist", experience: "Entry-Level", salary: 75000, department: "Analytics" },
        { name: "Ashley Young", jobTitle: "Marketing Manager", experience: "Mid-Level", salary: 95000, department: "Marketing" },
        { name: "Matthew Allen", jobTitle: "DevOps Engineer", experience: "Senior", salary: 135000, department: "Engineering" },
        { name: "Rebecca King", jobTitle: "Accountant", experience: "Mid-Level", salary: 65000, department: "Finance" },
        { name: "Andrew Wright", jobTitle: "Software Engineer", experience: "Senior", salary: 125000, department: "Engineering" },
        { name: "Amanda Scott", jobTitle: "UX Designer", experience: "Mid-Level", salary: 92000, department: "Design" },
        { name: "Kevin Green", jobTitle: "Data Analyst", experience: "Senior", salary: 100000, department: "Analytics" },
        { name: "Olivia Adams", jobTitle: "Product Manager", experience: "Mid-Level", salary: 110000, department: "Product" },
        { name: "Justin Baker", jobTitle: "Software Engineer", experience: "Entry-Level", salary: 68000, department: "Engineering" },
        { name: "Sophia Gonzalez", jobTitle: "HR Specialist", experience: "Entry-Level", salary: 58000, department: "Human Resources" },
        { name: "Brandon Nelson", jobTitle: "Data Scientist", experience: "Mid-Level", salary: 110000, department: "Analytics" },
        { name: "Emma Carter", jobTitle: "Marketing Manager", experience: "Entry-Level", salary: 62000, department: "Marketing" },
        { name: "Ryan Mitchell", jobTitle: "DevOps Engineer", experience: "Mid-Level", salary: 100000, department: "Engineering" },
        { name: "Grace Perez", jobTitle: "Accountant", experience: "Senior", salary: 80000, department: "Finance" }
    ];
    
    filteredData = [...salaryData];
    populateFilters();
    updateStatistics();
    renderCharts();
    renderTable();
}

// Handle CSV file upload
function handleFileUpload() {
    const file = csvFileInput.files[0];
    
    if (!file) {
        fileInfo.textContent = "Please select a CSV file first.";
        fileInfo.style.backgroundColor = "#ffebee";
        fileInfo.style.color = "#c62828";
        return;
    }
    
    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
        fileInfo.textContent = "Please upload a valid CSV file.";
        fileInfo.style.backgroundColor = "#ffebee";
        fileInfo.style.color = "#c62828";
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const content = e.target.result;
        parseCSV(content);
        fileInfo.textContent = `Successfully loaded ${file.name} with ${salaryData.length} records.`;
        fileInfo.style.backgroundColor = "#e8f5e9";
        fileInfo.style.color = "#2e7d32";
    };
    
    reader.onerror = function() {
        fileInfo.textContent = "Error reading file. Please try again.";
        fileInfo.style.backgroundColor = "#ffebee";
        fileInfo.style.color = "#c62828";
    };
    
    reader.readAsText(file);
}

// Parse CSV content
function parseCSV(csv) {
    const lines = csv.split('\n');
    const headers = lines[0].split(',').map(header => header.trim());
    
    salaryData = [];
    
    for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim() === '') continue;
        
        const values = lines[i].split(',').map(value => value.trim().replace(/^"|"$/g, ''));
        
        if (values.length === headers.length) {
            const record = {};
            headers.forEach((header, index) => {
                record[camelCase(header)] = values[index];
            });
            salaryData.push(record);
        }
    }
    
    // Convert salary to number if it's a string
    salaryData.forEach(record => {
        if (typeof record.salary === 'string') {
            record.salary = parseFloat(record.salary.replace(/[^0-9.-]+/g,"")) || 0;
        }
    });
    
    filteredData = [...salaryData];
    populateFilters();
    updateStatistics();
    renderCharts();
    renderTable();
}

// Convert string to camelCase
function camelCase(str) {
    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(word, index) {
        return index === 0 ? word.toLowerCase() : word.toUpperCase();
    }).replace(/\s+/g, '');
}

// Populate filter dropdowns
function populateFilters() {
    // Clear existing options
    jobFilter.innerHTML = '<option value="all">All Jobs</option>';
    experienceFilter.innerHTML = '<option value="all">All Levels</option>';
    
    // Get unique job titles and experience levels
    const jobTitles = [...new Set(salaryData.map(item => item.jobTitle))];
    const experienceLevels = [...new Set(salaryData.map(item => item.experience))];
    
    // Populate job filter
    jobTitles.forEach(job => {
        const option = document.createElement('option');
        option.value = job;
        option.textContent = job;
        jobFilter.appendChild(option);
    });
    
    // Populate experience filter
    experienceLevels.forEach(level => {
        const option = document.createElement('option');
        option.value = level;
        option.textContent = level;
        experienceFilter.appendChild(option);
    });
}

// Apply filters to the data
function applyFilters() {
    const jobValue = jobFilter.value;
    const experienceValue = experienceFilter.value;
    
    filteredData = salaryData.filter(item => {
        const jobMatch = jobValue === 'all' || item.jobTitle === jobValue;
        const experienceMatch = experienceValue === 'all' || item.experience === experienceValue;
        return jobMatch && experienceMatch;
    });
    
    updateStatistics();
    renderCharts();
    renderTable();
}

// Calculate and update statistics
function updateStatistics() {
    const totalRecords = filteredData.length;
    const salaries = filteredData.map(item => parseFloat(item.salary) || 0);
    
    const totalSalary = salaries.reduce((sum, salary) => sum + salary, 0);
    const avgSalary = totalRecords > 0 ? Math.round(totalSalary / totalRecords) : 0;
    
    // Sort salaries for median calculation
    const sortedSalaries = [...salaries].sort((a, b) => a - b);
    const medianSalary = totalRecords > 0 ? 
        sortedSalaries[Math.floor(sortedSalaries.length / 2)] : 0;
    
    const minSalary = totalRecords > 0 ? Math.min(...salaries) : 0;
    const maxSalary = totalRecords > 0 ? Math.max(...salaries) : 0;
    
    // Update DOM elements
    document.getElementById('totalRecords').textContent = totalRecords;
    document.getElementById('avgSalary').textContent = `$${avgSalary.toLocaleString()}`;
    document.getElementById('medianSalary').textContent = `$${medianSalary.toLocaleString()}`;
    document.getElementById('minSalary').textContent = `$${minSalary.toLocaleString()}`;
    document.getElementById('maxSalary').textContent = `$${maxSalary.toLocaleString()}`;
}

// Render data table
function renderTable() {
    // Clear existing table rows
    dataTable.innerHTML = '';
    
    // Add rows for each data item
    filteredData.forEach(item => {
        const row = dataTable.insertRow();
        row.insertCell(0).textContent = item.name;
        row.insertCell(1).textContent = item.jobTitle;
        row.insertCell(2).textContent = item.experience;
        row.insertCell(3).textContent = `$${parseFloat(item.salary).toLocaleString()}`;
        row.insertCell(4).textContent = item.department;
    });
}

// Render charts
function renderCharts() {
    // Destroy existing charts if they exist
    if (salaryChart) salaryChart.destroy();
    if (jobChart) jobChart.destroy();
    if (experienceChart) experienceChart.destroy();
    
    // Salary distribution chart
    const salaryCtx = document.getElementById('salaryChart').getContext('2d');
    const salaries = filteredData.map(item => parseFloat(item.salary) || 0);
    
    salaryChart = new Chart(salaryCtx, {
        type: 'bar',
        data: {
            labels: filteredData.map((_, i) => `Employee ${i+1}`),
            datasets: [{
                label: 'Salary ($)',
                data: salaries,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    
    // Salary by job title chart
    const jobCtx = document.getElementById('jobChart').getContext('2d');
    const jobTitles = [...new Set(filteredData.map(item => item.jobTitle))];
    const jobSalaries = jobTitles.map(job => {
        const jobs = filteredData.filter(item => item.jobTitle === job);
        const total = jobs.reduce((sum, item) => sum + (parseFloat(item.salary) || 0), 0);
        return Math.round(total / jobs.length);
    });
    
    jobChart = new Chart(jobCtx, {
        type: 'bar',
        data: {
            labels: jobTitles,
            datasets: [{
                label: 'Average Salary ($)',
                data: jobSalaries,
                backgroundColor: 'rgba(255, 99, 132, 0.6)',
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
    
    // Experience vs Salary chart
    const experienceCtx = document.getElementById('experienceChart').getContext('2d');
    const experienceLevels = [...new Set(filteredData.map(item => item.experience))];
    const experienceSalaries = experienceLevels.map(level => {
        const experiences = filteredData.filter(item => item.experience === level);
        const total = experiences.reduce((sum, item) => sum + (parseFloat(item.salary) || 0), 0);
        return Math.round(total / experiences.length);
    });
    
    experienceChart = new Chart(experienceCtx, {
        type: 'line',
        data: {
            labels: experienceLevels,
            datasets: [{
                label: 'Average Salary ($)',
                data: experienceSalaries,
                backgroundColor: 'rgba(75, 192, 192, 0.6)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 2,
                fill: false,
                tension: 0.1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                }
            }
        }
    });
}